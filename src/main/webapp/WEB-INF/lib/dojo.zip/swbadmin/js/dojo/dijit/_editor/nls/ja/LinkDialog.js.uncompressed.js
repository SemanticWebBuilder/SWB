define(
"dijit/_editor/nls/ja/LinkDialog", ({
	createLinkTitle: "リンク・プロパティー",
	insertImageTitle: "イメージ・プロパティー",
	url: "URL:",
	text: "説明:",
	target: "ターゲット: ",
	set: "設定",
	currentWindow: "現在のウィンドウ",
	parentWindow: "親ウィンドウ",
	topWindow: "最上位ウィンドウ",
	newWindow: "新規ウィンドウ"
})
);
