//>>built
define("dijit/_editor/nls/ro/LinkDialog",({createLinkTitle:"Proprietăţi legătură",insertImageTitle:"Proprietăţi imagine",url:"URL:",text:"Descriere:",target:"Destinaţie:",set:"Setare",currentWindow:"Fereastra curentă",parentWindow:"Fereastra părinte",topWindow:"Fereastra cea mai de sus",newWindow:"Fereastra nouă"}));
